<?php
/*
Plugin Name: SlickText API Explorer
Description: Explore SlickText API functionality from your WordPress dashboard.
Version: 1.0
Author: Your Name
*/

// Activation and deactivation hooks
register_activation_hook(__FILE__, 'slicktext_api_explorer_activate');
register_deactivation_hook(__FILE__, 'slicktext_api_explorer_deactivate');

function slicktext_api_explorer_activate() {
    // Activation logic, if any
}

function slicktext_api_explorer_deactivate() {
    // Deactivation logic, if any
}

// Plugin menu
add_action('admin_menu', 'slicktext_api_explorer_menu');

function slicktext_api_explorer_menu() {
    add_menu_page(
        'SlickText API Explorer',
        'SlickText API Explorer',
        'manage_options',
        'slicktext-api-explorer',
        'slicktext_api_explorer_page'
    );
}

// Save API Keys
if (isset($_POST['public_key']) && isset($_POST['private_key'])) {
    update_option('slicktext_public_key', sanitize_text_field($_POST['public_key']));
    update_option('slicktext_private_key', sanitize_text_field($_POST['private_key']));
}

// Plugin page content
function slicktext_api_explorer_page() {
    ?>
    <div class="wrap">
        <h1>SlickText API Explorer</h1>
        <form method="post" action="">
            <label for="public_key">Public Key:</label>
            <input type="text" name="public_key" value="<?php echo esc_attr(get_option('slicktext_public_key')); ?>" />
            
            <label for="private_key">Private Key:</label>
            <input type="text" name="private_key" value="<?php echo esc_attr(get_option('slicktext_private_key')); ?>" />

            <?php submit_button(); ?>
        </form>

        <?php
        // Make API Requests
        if (get_option('slicktext_public_key') && get_option('slicktext_private_key')) {
            ?>
            <form method="post" action="">
                <input type="hidden" name="retrieve_all_textwords" value="1" />
                <?php submit_button('Retrieve All Textwords', 'secondary', 'retrieve_all_textwords_button'); ?>
            </form>
            <?php

            if (isset($_POST['retrieve_all_textwords'])) {
                $api_url = 'https://api.slicktext.com/v1/textwords/';
                $response = wp_remote_get($api_url, array(
                    'headers' => array(
                        'Authorization' => 'Basic ' . base64_encode(get_option('slicktext_public_key') . ':' . get_option('slicktext_private_key')),
                    ),
                ));

                if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                    $api_data = json_decode(wp_remote_retrieve_body($response), true);
                    // Process and display API response data
                    echo '<h2>All Textwords</h2>';
                    echo '<pre>';
                    print_r($api_data);
                    echo '</pre>';
                } else {
                    // Handle API request failure
                    echo '<p style="color: red;">API Request Failed</p>';
                }
            }
        }
        ?>
    </div>
    <?php
}
